require("dotenv").config();

module.exports = {
  client: "mysql2",
  connection: {
    host: process.env.DB_HOST || "localhost",
    port: Number(process.env.DB_PORT || 3306),
    user: process.env.DB_USER || "root",
    password: process.env.DB_PASSWORD || "admin",
    database: process.env.DB_NAME || "kanban_system_v2"
  },
  migrations: {
    directory: "./migrations"
  },
  seeds: {
    directory: "./seeds"
  }
};
